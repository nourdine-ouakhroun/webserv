#include "Logger.hpp"

/*
Logger::Logger( void )
{
}
Logger::Logger(const Logger& copy)
{
	*this = copy;
}

Logger::~Logger( void )
{
}

Logger& Logger::operator=(const Logger& target)
{
	return (*this);
}

void	Logger::info(std::ostream& os, const String& message)
{
	os << "\033[0;37m[INFO] : " << message << "\033[0m" << std::endl;
}*/
